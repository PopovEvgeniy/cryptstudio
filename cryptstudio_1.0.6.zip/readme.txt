                                 CRYPT STUDIO

                                  Version 1.0.6

                         This software was made by Popov Evgeniy Alekseyevich

System requirements

Windows 2000 or higher for 32-bit systems
Windows Vista or higher for 64-bit systems

Program description

This program is a graphic shell for BLACK ICE.
Put the executable file of BLACK ICE in the CRYPT STUDIO directory before the first start.

License

This program is distributed under GNU GENERAL PUBLIC LICENSE.

Contact

You can send me a letter at tuzik87@inbox.ru.

About program modification

The code is included in the source.zip archive.
It can be compiled under Lazarus 4.0 RC3 or higher.

Change log

0.1: Initial version.
0.2: The small changes in the source code.
0.3: The program has improved.
0.4: The program was totally rewritten.
0.4.1-0.4.3: The small changes in the source code.
0.4.4: The program has been adapted to the new version of OPEN FILE CRYPTOR.
0.4.5-0.4.6: The small changes in the source code.
0.4.7: Russian localization has been removed.
0.4.8-0.4.9: The small changes in the source code.
0.5: The small changes in the source code.
0.6: The program has been adapted to BLACK ICE.
0.7: The program has been adapted to the new version of BLACK ICE.
0.8: The small changes.
0.9: A small bug has been fixed.
0.9.1: 64-bit support has been added.
0.9.2-0.9.5: The small changes.
0.9.5.1: The source code was recompiled under Lazarus 2.2.2.
0.9.5.2: The documentation has been updated.
0.9.6-0.9.8: The small changes.
0.9.9: A small bug has been fixed.
1.0-1.0.3: The small changes.
1.0.3.1: The documentation has been updated.
1.0.4: The small changes.
1.0.4.1-1.0.4.2: The documentation has been updated.
1.0.5: The source code was recompiled under Lazarus 4.0 RC1.
1.0.6: The source code was recompiled under Lazarus 4.0 RC3.